Kota Padawan pilot — Greater Kuching IOC
Generated with official Arnis 3.3.0. Exploratory Minecraft Java world, not a survey or flood simulation.
Open the extracted world in a compatible Minecraft Java client. One World uses an extended-height data pack; keep the whole folder intact.
File structure verified separately; in-game loading and walkthrough remain untested.
Source and projection bounds: metadata.json. Do not assume this is complete Padawan municipal coverage.
Building heights, facades and vegetation are rule-based representations, not field observations.
Sources: Arnis (Apache-2.0), OpenStreetMap contributors (ODbL), Overture Maps Foundation, Microsoft ML Buildings, Google Open Buildings.
Terrain and land cover: Mapterhorn, ESA WorldCover 2021, Meta/WRI canopy height.
Attribution details: https://docs.overturemaps.org/attribution/ ; https://www.openstreetmap.org/copyright
Generator: https://github.com/louis-e/arnis/releases/tag/v3.3.0
Dashboard: https://kuching.nonarkara.org/
